<?php $__env->startSection('content'); ?>
    <h1>Import/Export Questions</h1>
    <p>প্রথাম কলামে কোন হেডিং থাকবে না প্রশ্ন থাকবে১,৬,১১ অপশন থাকবে২,৩,৪,৫ দ্বিতীয় কলামে উপত্তর থাবে যে অপশনে উত্তর হবে তা
        ১ দিতে হবে উদাহরন <a target="_blank" href="https://docs.google.com/spreadsheets/d/1sIlH6yOAG16D5aIAhaOhSsYKASF0DI2k97bC8l9LNic/edit?usp=sharing">example</a>
    <p>
        <?php if(session('success')): ?>
            <p><?php echo e(session('success')); ?></p>
        <?php endif; ?>

        <!-- Import Form -->
    <form action="<?php echo e(route('admin.yearexam')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>


        <label for="i_title">Import Label:</label>
        <input type="text" name="i_title" id="i_title">


        <label for="subject_id">Subject:</label>
        <select name="subject_id" id="subject_id" required>
            <option value="">Select a Subject</option>
            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->s_title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label for="year_id">year:</label>
        <select name="year_id" id="year_id" required>
            <option value="">Select a year</option>
            <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($year->id); ?>"><?php echo e($year->y_title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>



        <label for="exam_id">exam:</label>
        <select name="exam_id" id="exam_id" required>
            <option value="">Select a exam</option>
            <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($exam->id); ?>"><?php echo e($exam->e_title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>


        <label class="file-input-label" for="file-input">Choose a file</label>
        <input type="file" id="file-input" name="file" accept=".xlsx,.csv">
        <br>
        <button type="submit">Import</button>
    </form>

    <!-- Export Button -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\liveexam\resources\views/backend/import/questions/year_exam_index.blade.php ENDPATH**/ ?>