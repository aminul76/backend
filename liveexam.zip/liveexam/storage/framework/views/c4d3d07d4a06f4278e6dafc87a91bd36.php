<?php $__env->startSection('content'); ?>
    <h1>Edit Option</h1>
    <?php if($errors->any()): ?>
        <div>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form action="<?php echo e(route('admin.options.update', $option->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label for="question_id">Question:</label>
        <select name="question_id" id="question_id">
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($question->id); ?>" <?php echo e($question->id == $option->question_id ? 'selected' : ''); ?>>
                    <?php echo e($question->q_title); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label for="p_title">Title:</label>
        <input type="text" name="p_title" id="p_title" value="<?php echo e($option->p_title); ?>">
        <label for="is_correct">Is Correct:</label>
        <input type="checkbox" name="is_correct" id="is_correct" value="1" <?php echo e($option->is_correct ? 'checked' : ''); ?>>
        <br>
                <button type="submit">Update</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\liveexam\resources\views/backend/options/edit.blade.php ENDPATH**/ ?>