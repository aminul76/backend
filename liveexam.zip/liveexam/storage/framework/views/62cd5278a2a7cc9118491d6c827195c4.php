<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Add Questions to Model Test: <?php echo e($modelTest->title); ?></h2>
    <p>Number of Questions: <?php echo e($questionCount); ?></p>

    <ul>
        <p>Subject</p>
        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <p>    <?php echo e($result->s_title); ?>  Question Count:  <?php echo e($result->question_count); ?> <br></p>



        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>


    <ul>

        <p>Topic</p>
        <?php $__currentLoopData = $topicscouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topicscout): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <p>   <?php echo e($topicscout->t_title); ?>  Question Count:  <?php echo e($topicscout->question_count); ?> <br></p>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.model-test.add-questions', $modelTest->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <input type="hidden" name="model_test_id" value="<?php echo e($modelTest->id); ?>">
        <div class="form-group">
            <label for="subject_id">Select Subject:</label>
            <select name="subject_id" id="subject_id" class="form-control" required>
                <option value="">-- Select Subject --</option>
                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->s_title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['subject_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label for="topic_id">Select Topic:</label>
            <select name="topic_id" id="topic_id" class="form-control" required>
                <option value="">-- Select Topic --</option>
                <!-- Topics will be loaded via JavaScript based on the selected subject -->
            </select>
            <?php $__errorArgs = ['topic_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label for="question_ids">Select Questions:</label>
            <select name="question_ids[]" id="question_ids" class="form-control" multiple required size="25">
                <!-- Questions will be loaded via JavaScript based on the selected topic -->
            </select>
            <?php $__errorArgs = ['question_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" class="btn btn-primary">Add Questions</button>
    </form>
</div>

<script>
 document.getElementById('subject_id').addEventListener('change', function() {
    var subjectId = this.value;
    if (subjectId) {
        fetch(`/admin/get-topics/${subjectId}`)
            .then(response => response.json())
            .then(data => {
                var topicSelect = document.getElementById('topic_id');
                topicSelect.innerHTML = '<option value="">-- Select Topic --</option>';
                data.topics.forEach(function(topic) {
                    topicSelect.innerHTML += `<option value="${topic.id}">${topic.t_title}</option>`;
                });
            })
            .catch(error => console.error('Error fetching topics:', error));
    } else {
        // Clear topics if no subject is selected
        document.getElementById('topic_id').innerHTML = '<option value="">-- Select Topic --</option>';
    }
});
document.getElementById('topic_id').addEventListener('change', function() {
    var topicId = this.value;
    if (topicId) {
        fetch(`/admin/get-questions/${topicId}`)
            .then(response => response.json())
            .then(data => {
                var questionSelect = document.getElementById('question_ids');
                questionSelect.innerHTML = '';

                data.questions.forEach(function(question) {
                    // Create a string with question title and associated exam titles
                    var examTitles = question.exams.map(exam => exam.e_title).join(', ');
                    questionSelect.innerHTML += `<option value="${question.id}">${question.q_title} (Exams: ${examTitles})</option>`;
                });
            });
    }
});


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\liveexam\resources\views/backend/model_tests/generate/add-questions.blade.php ENDPATH**/ ?>