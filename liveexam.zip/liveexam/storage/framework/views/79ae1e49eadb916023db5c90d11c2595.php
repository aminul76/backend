<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="<?php echo e(asset('backend/styles.css')); ?>">
     <!-- jQuery -->
     <script src="<?php echo e(asset('plugins/jquery-3.6.0.min.js')); ?>"></script>
     <!-- DataTables CSS -->
     <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/jquery.dataTables.min.css')); ?>"/>
     <!-- DataTables JS -->
     <script type="text/javascript" charset="utf8" src="<?php echo e(asset('plugins/jquery.dataTables.min.js')); ?>"></script>
</head>
<body>
    <?php echo $__env->make('backend.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="main-content">
       <?php echo $__env->make('backend.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <?php echo $__env->yieldContent('content'); ?>
    </div>


  <script>
    $(document).ready(function() {
        $('#dTable').DataTable();
    });
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\liveexam\resources\views/backend/master.blade.php ENDPATH**/ ?>