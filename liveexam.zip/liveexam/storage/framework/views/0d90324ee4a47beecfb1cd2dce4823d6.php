<div class="header">
    <h2>Dashboard</h2>
    
</div><?php /**PATH C:\xampp\htdocs\liveexam\resources\views/backend/include/header.blade.php ENDPATH**/ ?>