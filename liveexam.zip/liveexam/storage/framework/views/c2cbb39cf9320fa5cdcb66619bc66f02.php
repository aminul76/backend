<?php $__env->startSection('content'); ?>
    <h1>Edit Model Test</h1>
    <form action="<?php echo e(route('admin.model_tests.update', $modelTest->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div>
            <label for="title">Title</label>
            <input type="text" name="title" id="title" value="<?php echo e(old('title', $modelTest->title)); ?>">
        </div>
        <div>
            <label for="slug">Slug</label>
            <input type="text" name="slug" id="slug" value="<?php echo e(old('slug', $modelTest->slug)); ?>">
        </div>
        <div>
            <label for="course_id">Course</label>
            <select name="course_id" id="course_id">
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($course->id); ?>" <?php echo e($course->id == $modelTest->course_id ? 'selected' : ''); ?>>
                        <?php echo e($course->c_title); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div>
            <label for="status">Status</label>
            <input type="number" name="status" id="status" value="<?php echo e(old('status', $modelTest->status)); ?>">
        </div>
        <div>
            <label for="start_date">Start Date</label>
            <input type="datetime-local" name="start_date" id="start_date" value="<?php echo e(old('start_date', $modelTest->start_date->format('Y-m-d\TH:i'))); ?>">
        </div>
        <div>
            <label for="end_date">End Date</label>
            <input type="datetime-local" name="end_date" id="end_date" value="<?php echo e(old('end_date', $modelTest->end_date->format('Y-m-d\TH:i'))); ?>">
        </div>
        <button type="submit">Update</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\liveexam\resources\views/backend/model_tests/edit.blade.php ENDPATH**/ ?>