<?php $__env->startSection('content'); ?>
    <h1>Model Tests</h1>
    <a href="<?php echo e(route('admin.model_tests.create')); ?>">Create New Model Test</a>


    <table id="dTable" class="display">
        <thead>
            <tr>
                <th>ID</th>

                <th>Title</th>
                <th>Course</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $modelTests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelTest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($modelTest->id); ?></td>
                    <td><?php echo e($modelTest->title); ?></td>
                    
                    <td><?php echo e($modelTest->course->c_title); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.model-test.add-questions.form',$modelTest->id)); ?>">Add Question</a>
                <a href="<?php echo e(route('admin.model_tests.edit', $modelTest->id)); ?>">Edit</a>
                <form action="<?php echo e(route('admin.model_tests.destroy', $modelTest->id)); ?>" method="POST" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit">Delete</button>
                </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\liveexam\resources\views/backend/model_tests/index.blade.php ENDPATH**/ ?>