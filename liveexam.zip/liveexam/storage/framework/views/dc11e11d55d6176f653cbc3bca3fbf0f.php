<?php $__env->startSection('content'); ?>
    <h1>Create Question</h1>

    <form action="<?php echo e(route('admin.questions.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <label for="subject_id">Subject:</label>
        <select name="subject_id" id="subject_id" required>
            <option value="">Select a Subject</option>
            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->s_title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>




        <label for="topic_id">Topic:</label>
        <select name="topic_id" id="topic_id" required>
            <option value="">Select a Topic</option>
            <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($topic->id); ?>"><?php echo e($topic->t_title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>



        <label for="years">Select Years:</label>
        <select name="years[]" id="years" multiple>
            <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($year->id); ?>"><?php echo e($year->y_title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>




        <label for="exams">Select Exam:</label>
        <select name="exams[]" id="exams" multiple>
            <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($exam->id); ?>"><?php echo e($exam->e_title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>


        <label for="q_title">Title:</label>
        <input type="text" name="q_title" id="q_title" required>

        <label for="q_slug">Slug:</label>
        <input type="text" name="q_slug" id="q_slug" required>

        <label for="q_explain">Explanation:</label>
        <textarea name="q_explain" id="q_explain" required></textarea>

        <button type="submit">Create</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\liveexam\resources\views/backend/questions/create.blade.php ENDPATH**/ ?>