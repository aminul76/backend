


<?php $__env->startSection('content'); ?>
    <h1>Edit Exam</h1>
    <?php if($errors->any()): ?>
        <div>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form action="<?php echo e(route('admin.exams.update', $exam->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label for="e_title">Title:</label>
        <input type="text" name="e_title" id="e_title" value="<?php echo e($exam->e_title); ?>">
        <label for="e_slug">Slug:</label>
        <input type="text" name="e_slug" id="e_slug" value="<?php echo e($exam->e_slug); ?>">
        <button type="submit">Update</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\liveexam\resources\views/backend/exams/edit.blade.php ENDPATH**/ ?>