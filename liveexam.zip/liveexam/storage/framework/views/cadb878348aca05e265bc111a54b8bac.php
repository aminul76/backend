<div class="sidebar">
    <div class="logo">
        <h2>Admin</h2>
    </div>
    <ul>
        <li><a href="#">Dashboard</a></li>

        <li><a href="<?php echo e(route('admin.courses.index')); ?>">Courses</a></li>
        <li>
            <a href="">Subject Item</a>
            <ul class="submenu">
                <li><a href="<?php echo e(route('admin.subjects.index')); ?>">Subjects</a></li>
                <li><a href="<?php echo e(route('admin.topics.index')); ?>">Topics</a></li>
                <li><a href="<?php echo e(route('admin.exams.index')); ?>">Exam</a></li>
                <li><a href="<?php echo e(route('admin.years.index')); ?>">Years</a></li>

            </ul>
        </li>

        <li>
            <a href="">Question</a>
            <ul class="submenu">
                <li><a href="<?php echo e(route('admin.questions.index')); ?>">Question</a></li>
                <li><a href="<?php echo e(route('admin.yearexam.index')); ?>">ImportQuestion</a></li>
                <li><a href="<?php echo e(route('admin.explan.index')); ?>">Import Q Explan </a></li>
                <li><a href="<?php echo e(route('admin.label.index')); ?>">Import Lebal Topic</a></li>
                <li><a href="<?php echo e(route('admin.options.index')); ?>">Option</a></li>

            </ul>
        </li>


        <li>
            <a href="">Model Test Generate</a>
            <ul class="submenu">
                <li><a href="<?php echo e(route('admin.model_tests.index')); ?>">Model test</a></li>
                <li><a href="#">Generate Question</a></li>
                <li><a href="<?php echo e(route('admin.explan.index')); ?>">Import Q Explan </a></li>
                <li><a href="<?php echo e(route('admin.label.index')); ?>">Import Lebal Topic</a></li>
                <li><a href="<?php echo e(route('admin.options.index')); ?>">Option</a></li>

            </ul>
        </li>

        <li><a href="#">Reports</a></li>
        <li><a href="#">Logout</a></li>

    </ul>
</div>
<?php /**PATH C:\xampp\htdocs\liveexam\resources\views/backend/include/sidebar.blade.php ENDPATH**/ ?>