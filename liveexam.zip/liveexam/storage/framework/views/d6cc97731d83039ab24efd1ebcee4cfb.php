<?php $__env->startSection('content'); ?>

<h1>Questions List</h1>

<div class="container">
    <h1>
        <?php if($topicStatus==1): ?>
        <p>topic already add</p>
    <?php else: ?>
    <p>no topic add</p>
    <?php endif; ?></h1>

    <?php if($questions->isNotEmpty()): ?>
        <form action="<?php echo e(route('admin.updateTopics')); ?>" method="POST">

            
            <?php echo csrf_field(); ?>
            <table>
                <thead>
                    <tr>
                        <th>Question Title</th>
                        <th>Option Title</th>
                        <th>Select Topic</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $questions->groupBy('question_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $questionId => $groupedOptions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $firstOption = $groupedOptions->first();
                        ?>
                        <tr>
                            <input  type="hidden" name="firstOption" value="<?php echo e($firstOption->question_id); ?>">
                            <td><?php echo e($firstOption->q_title); ?></td>
                            <td><?php echo e($groupedOptions->first()->p_title); ?></td>
                            <td>
                                <select name="topics[<?php echo e($questionId); ?>]" required>
                                    <option value="">Select a topic</option>
                                    <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($topic->id); ?>"
                                            <?php echo e(old("topics.$questionId") == $topic->id ? 'selected' : ''); ?>>
                                            <?php echo e($topic->t_title); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>

                        </tr>
                        <?php $__currentLoopData = $groupedOptions->slice(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td></td>
                                <td><?php echo e($option->p_title); ?></td>
                                <td></td> <!-- Empty cell to match the header layout -->
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <button type="submit">Save</button>
        </form>
    <?php else: ?>
        <p>No questions found.</p>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\liveexam\resources\views/backend/import/label/subject.blade.php ENDPATH**/ ?>