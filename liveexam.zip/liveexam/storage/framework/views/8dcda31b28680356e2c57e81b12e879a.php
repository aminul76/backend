<?php $__env->startSection('content'); ?>
    <h1>Subject Item Years List</h1>
    <a href="<?php echo e(route('admin.years.create')); ?>">Create New Year</a>
    <?php if($message = Session::get('success')): ?>
        <p><?php echo e($message); ?></p>
    <?php endif; ?>
    <table id="dTable" class="display">
        <thead>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Slug</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($year->id); ?></td>
                    <td><?php echo e($year->y_title); ?></td>
                    <td><?php echo e($year->y_slug); ?></td>
                    <td>
                        <a  href="<?php echo e(route('admin.years.edit', $year->id)); ?>">Edit</a>
                        <form action="<?php echo e(route('admin.years.destroy', $year->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\liveexam\resources\views/backend/years/index.blade.php ENDPATH**/ ?>