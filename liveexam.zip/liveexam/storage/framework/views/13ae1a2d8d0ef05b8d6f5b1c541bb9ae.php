<?php $__env->startSection('content'); ?>
    <h1>Subject Item Subjects List</h1>
    <a href="<?php echo e(route('admin.subjects.create')); ?>">Create New Subject</a>
    <?php if($message = Session::get('success')): ?>
        <p><?php echo e($message); ?></p>
    <?php endif; ?>
    <table id="dTable" class="display">
        <thead>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Slug</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($subject->id); ?></td>
                    <td><?php echo e($subject->s_title); ?></td>
                    <td><?php echo e($subject->s_slug); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.subjects.edit', $subject->id)); ?>">Edit</a>
                        <form action="<?php echo e(route('admin.subjects.destroy', $subject->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\liveexam\resources\views/backend/subjects/index.blade.php ENDPATH**/ ?>