





<!DOCTYPE html>
<html>
<head>
    <title>Import/Export Questions</title>
</head>
<body>
    <h1>Import/Export Questions</h1>

    <?php if(session('success')): ?>
        <p><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <!-- Import Form -->
    <form action="<?php echo e(route('import')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="file" name="file" accept=".xlsx,.csv">
        <button type="submit">Import Questions</button>
    </form>

    <!-- Export Button -->
    <a href="<?php echo e(route('export')); ?>">Export Questions</a>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\liveexam\resources\views/import.blade.php ENDPATH**/ ?>