<?php $__env->startSection('content'); ?>
    <h1>Edit Question</h1>

    <form action="<?php echo e(route('admin.questions.update', $question->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <label for="subject_id">Subject:</label>
        <select name="subject_id" id="subject_id" required>
            <option value="">Select a Subject</option>
            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($subject->id); ?>" <?php echo e($question->subject_id == $subject->id ? 'selected' : ''); ?>>
                    <?php echo e($subject->s_title); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label for="topic_id">Topic:</label>
        <select name="topic_id" id="topic_id" required>
            <option value="">Select a Topic</option>
            <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($topic->id); ?>" <?php echo e($question->topic_id == $topic->id ? 'selected' : ''); ?>>
                    <?php echo e($topic->t_title); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <label for="years">Select Years:</label>
        <select name="years[]" id="years" multiple>
            <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($year->id); ?>"
                    <?php if(in_array($year->id, $question->years->pluck('id')->toArray())): ?>
                        selected
                    <?php endif; ?>>
                    <?php echo e($year->y_title); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>


        <label for="exams">Select exams:</label>
        <select name="exams[]" id="exams" multiple>
            <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($exam->id); ?>"
                    <?php if(in_array($exam->id, $question->exams->pluck('id')->toArray())): ?>
                        selected
                    <?php endif; ?>>
                    <?php echo e($exam->e_title); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>


        <label for="q_title">Title:</label>
        <input type="text" name="q_title" id="q_title" value="<?php echo e($question->q_title); ?>" required>

        <label for="q_slug">Slug:</label>
        <input type="text" name="q_slug" id="q_slug" value="<?php echo e($question->q_slug); ?>" required>

        <label for="q_explain">Explanation:</label>
        <textarea name="q_explain" id="q_explain" required><?php echo e($question->q_explain); ?></textarea>

        <button type="submit">Update</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\liveexam\resources\views/backend/questions/edit.blade.php ENDPATH**/ ?>