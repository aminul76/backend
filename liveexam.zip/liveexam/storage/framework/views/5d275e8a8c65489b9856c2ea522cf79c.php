<?php $__env->startSection('content'); ?>
    <h1>labels List</h1>

    <?php if($message = Session::get('success')): ?>
        <p><?php echo e($message); ?></p>
    <?php endif; ?>
    <table id="dTable" class="display">
        <thead>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Slug</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $labels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($label->id); ?></td>
                    <td><?php echo e($label->i_title); ?></td>
                    <td><?php echo e($label->i_slug); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.label.subject', $label->id)); ?>">Edit</a>
                        <form action="<?php echo e(route('admin.import-label.destroy', $label->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\liveexam\resources\views/backend/import/label/index.blade.php ENDPATH**/ ?>