<?php $__env->startSection('content'); ?>



<h1>Questions List </h1>


<h1><?php echo e($topic->t_title); ?></h1>
        <?php $__currentLoopData = $label->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="question">
                <h2><?php echo e($question->q_title); ?></h2>
                <p><?php echo e($question->q_explain); ?></p>

                <ul class="options">
                    <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <label>
                                <input type="radio" name="question_<?php echo e($question->id); ?>" value="<?php echo e($option->id); ?>">
                                <?php echo e($option->p_title); ?>

                                <?php if($option->is_correct): ?>
                                    <span>(Correct Answer)</span>
                                <?php endif; ?>
                            </label>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\liveexam\resources\views/backend/import/label/subjecttopic.blade.php ENDPATH**/ ?>