<?php $__env->startSection('content'); ?>
    <h1>Options List</h1>
    <a href="<?php echo e(route('admin.options.create')); ?>">Create New Option</a>
    <?php if($message = Session::get('success')): ?>
        <p><?php echo e($message); ?></p>
    <?php endif; ?>
    <table id="dTable" class="display">
        <thead>
            <tr>
                <th>ID</th>
                <th>Question</th>
                <th>Title</th>
                <th>Is Correct</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($option->id); ?></td>
                    <td><?php echo e($option->question->q_title); ?></td>
                    <td><?php echo e($option->p_title); ?></td>
                    <td><?php echo e($option->is_correct == 1 ? 'Yes' : 'No'); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.options.edit', $option->id)); ?>">Edit</a>
                        <form action="<?php echo e(route('admin.options.destroy', $option->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\liveexam\resources\views/backend/options/index.blade.php ENDPATH**/ ?>