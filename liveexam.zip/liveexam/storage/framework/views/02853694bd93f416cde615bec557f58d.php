<?php $__env->startSection('content'); ?>
    <h1>Questions</h1>

    <a href="<?php echo e(route('admin.questions.create')); ?>" style="margin-bottom: 20px; display: inline-block;">Create New Question</a>

    <?php if(session('success')): ?>
        <div style="color: green;">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table id="dTable" class="display">
      <thead>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Slug</th>
                <th>Subject</th>
                <th>Topic</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($question->id); ?></td>
                    <td><?php echo e($question->q_title); ?></td>
                    <td><?php echo e($question->q_slug); ?></td>
                    <td><?php echo e($question->subject->s_title ?? 'N/A'); ?></td>
                    <td><?php echo e($question->topic->t_title ?? 'N/A'); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.questions.edit', $question->id)); ?>">Edit</a>
                        <form action="<?php echo e(route('admin.questions.destroy', $question->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" onclick="return confirm('Are you sure you want to delete this question?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\liveexam\resources\views/backend/questions/index.blade.php ENDPATH**/ ?>